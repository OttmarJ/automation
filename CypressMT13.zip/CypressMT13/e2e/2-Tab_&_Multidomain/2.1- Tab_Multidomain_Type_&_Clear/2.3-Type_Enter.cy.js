/*
DESCRIPCION
*/

describe(`Type_enter`, function () {
  it(`uso del enter`, function () {
    Cypress.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    cy.visit("https://www.google.com/?hl=es");
    cy.title("Google").should("eq", "Google");
    cy.wait(1500);
    cy.get(".gLFyf").type("Cypress.io {enter}");
    cy.wait(1500);
  });
});
