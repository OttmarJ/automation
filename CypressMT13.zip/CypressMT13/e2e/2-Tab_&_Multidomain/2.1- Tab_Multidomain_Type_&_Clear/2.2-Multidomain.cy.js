/*
DESCRIPCION
*/

/// <reference types="cypress" />
describe(`multidomain`, function () {
  it(`Casiolandia`, function () {
    Cypress.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    cy.visit(
      "https://casiostore.rower.com.ve/collections/casual-para-ellos?page=6&grid_list=grid-view"
    );
    cy.fixture("sld").then((sld) => {
      this.sld = sld;
      cy.clearLocalStorage();
      cy.clearCookies();
      cy.wait(5000);
    });
  });

  it(`Google acoounts`, function () {
    cy.visit(
      `https://accounts.google.com/signin/v2/identifier?hl=es&flowName=GlifWebSignIn&flowEntry=ServiceLogin`
    );

    cy.get(`[name="identifier"]`).type("YYYYYY@gmail.com", { force: true });
    cy.contains(`Siguiente`).click({ force: true });
    cy.wait(5000);
    //    cy.contains("No se ha podido iniciar sesión");
  });
});
