/*
DESCRIPCION
*/

//PRECONDICIONES
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("03_type_ &_Clear_Scenario", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://fastinsuranceservices.net/#/car-1-year");
  });

  it("QuoteOneCar", function () {
    //  How Many Vehicles Need Coverage?//
    cy.get(":nth-child(1) > .btn > img").click({ force: true });
    cy.wait(5000);
    // Select Vehicle year//
    cy.get(":nth-child(40) > .btn").click({ force: true });

    //Select  a make//
    cy.get(
      ".step-car-makes > :nth-child(2) > .col-lg-12 > .row > :nth-child(2) > .btn"
    ).click({ force: true });

    // Select Vehicle Model//
    cy.wait(5000);
    cy.get(".step-car-models > .form-group > .custom-form-control").type(
      "Blazer"
    );
    cy.wait(5000);
    cy.get(".step-car-models > .form-group > .custom-form-control").clear();
    cy.wait(5000);
    cy.get(".step-car-models > .form-group > .custom-form-control").type("C10");
  });
});
