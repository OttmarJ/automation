/*
DESCRIPCION
*/

/////////////////////////
//precondiciones
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("PageDown_PageUp", () => {
  beforeEach(function () {
    cy.visit("https://demoqa.com/automation-practice-form");
  });

  ////////////////////////////////////////////////////////////////////////////////

  it("01_test", { timeout: 1000 }, function () {
    ///////////////
    cy.get("#firstName").type("{pageup}");
    cy.wait(1500);
  });

  it("02_test", { timeout: 1000 }, function () {
    //////////////////
    cy.get("#userEmail").type("{pagedown}");
    cy.wait(1500);
  });

  it("03_test", { timeout: 1000 }, function () {
    cy.get("#firstName").type("{pageup}");
    cy.wait(1500);
    //FIN DEL TEST//
  });
});
