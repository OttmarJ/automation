/*
DESCRIPCION
*/
//PRECONDICION
//requiere de la instalacion del plugin tab npm install -D cypress-plugin-tab
//npm install -D cypress-plugin-tab
//At the top of cypress/support/index.js:
//require('cypress-plugin-tab')
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Tab_ ", () => {
  it("Tab", function () {
    cy.visit("https://demoqa.com/automation-practice-form");
    cy.get("#firstName").type("prueba").tab();
    cy.wait(1500);
    cy.get("#lastName").type("prueba1").tab();
    cy.wait(1500);
    cy.get("#userEmail").type("prueba@gmail,com").tab();
    // );
  });
});
