/*
Testcase/Escenario/Descripcion

Desarrollar test el cual permita la seleccion de fechas (dias and date and time)
posterior a la conexion de la pagina 

//PRECONDICIONES

 
 
*/
require("@cypress/xpath");

/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Seleccion de fechas ", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
  });

  it("01_Select_Menu.", function () {
    cy.visit("https://demoqa.com/select-menu");

    /* ==== Generated with Cypress Studio ==== */
    cy.get(
      "#withOptGroup > .css-yk16xz-control > .css-1wy0on6 > .css-tlfecz-indicatorContainer > .css-19bqh2r"
    ).click();
    cy.get(".css-1pahdxg-control > .css-1hwfws3").click();
    cy.get("#withOptGroup").click();
    cy.get("#react-select-2-option-0-0").click();
    /* ==== End Cypress Studio ==== */
  });
});
//});
