/*
Testcase/Escenario/Descripcion
Desarrolla un  test que depues del proceso de enganche permita la comprobacion
de alertas en una pagina


//PRECONDICIONES

 
 
*/
require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("generacion de alertas", () => {
  beforeEach(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://the-internet.herokuapp.com/javascript_alerts");
  });

  it("Click Button to see alert.", function () {
    cy.get(":nth-child(1) > button").click();
    //cy.contains("You successfully clicked an alert");

    cy.wait(5000);
    cy.get(":nth-child(2) > button").click();
    cy.wait(5000);
    cy.contains("You clicked: Ok");
  });
});
