/*
Testcase/Escenario/descripcion
Desarrollar u para la asignacion de alias 



//PRECONDICIONES

 
 
*/
require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Alias ", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://demoqa.com/automation-practice-form");
  });

  it("Alias", function () {
    cy.get("#firstName").as("nom");

    cy.get("@nom").type("prueba");
    cy.wait(1500);
    cy.get("#lastName").as("apell").type("prueba1");
  });
});
