/*
Testcase/Escenario/Descripcion

Desarrollar test el cual permita la seleccion de fechas (dias and date and time)
posterior a la conexion de la pagina 

//PRECONDICIONES

 
 
*/
require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Seleccion de fechas ", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://demoqa.com/date-picker");
  });

  it("01_Select_day.", function () {
    cy.get("#datePickerMonthYearInput").focus().click();
    cy.wait(1500);
    cy.get(".react-datepicker__month-select").select("April");
    cy.wait(1500);
    cy.get(".react-datepicker__year-select").select("2025");
    cy.wait(1500);
    cy.get(".react-datepicker__day--015").click();
    cy.wait(1500);
  });
  it("02_Date And Time", function () {
    cy.visit("https://demoqa.com/date-picker");
    cy.wait(1500);
    cy.get("#dateAndTimePickerInput").focus().click();
    cy.wait(1500);
    cy.get(".react-datepicker__month-read-view--selected-month").click();
    cy.xpath(
      "//div[@class='react-datepicker__header__dropdown react-datepicker__header__dropdown--scroll']//div[4]"
    ).click();
    cy.wait(1500);
    cy.get(".react-datepicker__day--019").click();
    cy.wait(1500);
    cy.get(":nth-child(58)").click();
  });
});
