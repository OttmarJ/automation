/*
Testcase/Escenario/Descripcion
Desarrollar un test que posterior  al enganche 



//PRECONDICIONES

 
*/
require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
//Test
describe("permita la generacion de alertas", () => {
  beforeEach(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://the-internet.herokuapp.com/javascript_alerts");
  });

  it("Click Button to see alert.", function () {
    cy.get(":nth-child(1) > button").click();
    //cy.contains("You successfully clicked an alert");

    cy.wait(5000);
    cy.get(":nth-child(2) > button").click();
    cy.contains("You clicked: Ok");
  });
});
//  it("click JS prompt ", function () {
//  cy.get(":nth-child(3) > button").click();
//cy.on("window:alert", (text) => {
//expect(text).to.equal("I am a JS prompt:");
//cy.window().then((win) => win.prompt("I am a JS prompt"));
//});
//});
