/*
DESCRIPCION
-- Desarrrollar un gancho que permita  la conexion a una pagina
 web empleando  before y a ftereach
*/
//
//PRECONDICIONES

//<reference types="cypress" />;
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Expresiones_Regulares", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://www.mercantilseguros.com/login.html");
  });
  it("Regex", function () {
    cy.get(
      ".mr-login-left > .login-content > .login-boton-container > .login-cta"
    ).click();
  });
  afterEach(function () {
    cy.log("after Each test");
  });
});

////////////////
