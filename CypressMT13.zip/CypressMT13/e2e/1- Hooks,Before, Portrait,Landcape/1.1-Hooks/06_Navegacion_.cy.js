/*
DESCRIPCION
*/

//PRECONDICIONES
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Simple_hook", function () {
  it("Simple_hook", function () {
    cy.viewport(1294, 668);

    cy.visit("https://demoqa.com/");

    cy.get(":nth-child(5) > :nth-child(1) > .card-body").click();
    cy.wait(3000);
    cy.go(-1);
    cy.wait(3000);
    cy.go("forward");
  });
});
