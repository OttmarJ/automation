/*
DESCRIPCION
*/

//PRECONDICIONES
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Simple_hook", function () {
  it("Simple_hook", function () {
    cy.viewport(1294, 668);

    cy.visit("https://fastinsuranceservices.net/#/car-coverage");

    cy.get(
      ".col-lg-12 > .row > .col-sm-4:nth-child(1) > .btn > .car-coverage-number"
    ).click({ force: true });

    cy.get(".row > .col-lg-12 > .row > .col-sm-4 > #car_coverage_0").type(
      "on",
      { force: true }
    );

    cy.get(
      ".carousel-inner > .step > .option-input-group > span > .btn-car-0-year"
    ).click({ force: true });

    cy.get(
      ".carousel-inner > .step > .option-input-group > span > #car_0_year_2023"
    ).type("on", { force: true });
  });
});
