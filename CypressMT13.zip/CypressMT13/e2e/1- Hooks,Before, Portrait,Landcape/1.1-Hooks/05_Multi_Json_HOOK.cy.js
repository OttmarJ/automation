/*
DESCRIPCION
*/

//PRECONDICIONES
//<reference types="cypress" />;

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("01_landscape_View_Scenarios", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://demoqa.com/automation-practice-form");
    cy.fixture("sld3").then((sld3) => {
      this.sld3 = sld3;
      cy.wait(5000);
    });
  });
  it("TEST_01", function () {
    cy.get("#firstName").type(this.sld3.firstname);
    cy.get("#lastName").type(this.sld3.lastname);
    cy.get("#userEmail").type(this.sld3.email);
    //
  });
  it("TEST_02", function () {
    cy.visit("https://demoqa.com/text-box");
    cy.fixture("sld").then((sld) => {
      this.sld = sld;
      cy.get("#userName").type(this.sld.make);
      cy.get("#userEmail").type(this.sld.Modelo);
    });
  });

  afterEach(function () {
    cy.log("prueba MULTITEST");
    cy.reload();
  });
});

////////////////
