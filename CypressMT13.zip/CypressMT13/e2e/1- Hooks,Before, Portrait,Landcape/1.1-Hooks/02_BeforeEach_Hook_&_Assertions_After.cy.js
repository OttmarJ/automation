/*DESCRIPCION
desarrollar  un test para conectarse a una pagina  web empleando 
beforeEach  y aserciones tales como should y contains  y completar el 
test  con un conjunto de postcondiciones como lo son 
limpiar las cookies   y el local storage 
*/

//PRECONDICIONES
//<reference types="cypress" />;

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
// TEST
describe("BeforeEach_Hook_Scenarios", () => {
  beforeEach(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://www.mercantilseguros.com/login.html");
    cy.wait(5000);
  });

  it("Aserciones", function () {
    cy.contains("Clientes");
    cy.wait(20000);
  });

  it("test #1", () => {
    cy.get("#mainMenu > :nth-child(2) > a").click();
    cy.get(
      ".active > .banner-content > .banner-left > .banner-6-content-wrapper > .banner-6-bottom > .cta-btn-banner6"
    ).should("be.visible");
  });
  it("test #2", () => {
    cy.contains("Empresas").click();
    cy.go(-1);
    cy.wait(2000);
  });

  after(() => {
    cy.clearLocalStorage();
    cy.clearCookies();
  });
});
