/*
DESCRIPCION
*/

//PRECONDICIONES
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Simple_hook with reload", function () {
  it("Simple_hook with reload", function () {
    cy.viewport(1294, 668);

    cy.visit("https://demoqa.com/");

    cy.get(":nth-child(5) > :nth-child(1) > .card-body").click();
    cy.wait(1500);
    cy.get(":nth-child(1) > .group-header > .header-wrapper").click();
    cy.wait(1500);
    cy.get(":nth-child(1) > .element-list > .menu-list > #item-0").click();
    cy.get("#userName").type("Pruebas0");
    cy.get("#userEmail").type("Pruebas1");
    cy.reload();
    cy.wait(1500);
    cy.go(-1);
  });
});
