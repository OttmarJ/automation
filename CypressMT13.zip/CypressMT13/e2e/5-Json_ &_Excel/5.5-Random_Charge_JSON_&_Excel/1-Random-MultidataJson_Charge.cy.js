/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Json_MULTIDATA", () => {
  it("JSON_test_MULTIDATA", { timeout: 1000 }, function () {
    cy.visit("https://demoqa.com/automation-practice-form");
    cy.wait(1000);
    cy.fixture("sld4").then((testdata) => {
      testdata.forEach((data, index) => {
        const randomIndex = Math.floor(Math.random() * testdata.length); // Seleccionar índice aleatorio
        const randomData = testdata[randomIndex]; // Obtener datos del índice aleatorio

        const d_firstname = randomData.firstname;
        const d_lastname = randomData.lastname;
        const d_email = randomData.email;
        const d_tel = randomData.tel;
        const d_sub = randomData.sub;
        const d_ca = randomData.ca;

        cy.get("#firstName").type(d_firstname);
        cy.get("#lastName").type(d_lastname);
        cy.wait(250);
        cy.get("#userEmail").type(d_email);
        cy.wait(250);
        cy.get("#genterWrapper > .col-md-9 > :nth-child(2)").click();
        cy.wait(250);
        cy.get("#userNumber").type(d_tel);
        cy.wait(250);
        cy.get("#dateOfBirthInput").click();
        cy.wait(250);
        cy.get(".react-datepicker__day--022").click();
        cy.wait(250);
        cy.get(".subjects-auto-complete__value-container").type(d_sub);
        cy.wait(250);
        cy.get("#hobbiesWrapper > .col-md-9 > :nth-child(1)").click();
        cy.wait(250);
        cy.get("#currentAddress").type(d_ca);
        cy.wait(250);

        // Mostrar el mensaje de registro insertado

        // Recargar la página
        cy.reload();
        cy.wait(300);
        // Verificar que los objetos de la página existan
        cy.get("#firstName").should("exist");
        cy.get("#lastName").should("exist");
        cy.get("#userEmail").should("exist");
        cy.get("#userNumber").should("exist");
        cy.get("#dateOfBirthInput").should("exist");
        cy.get(".subjects-auto-complete__value-container").should("exist");
        cy.get("#hobbiesWrapper").should("exist");
        cy.get("#currentAddress").should("exist");
        cy.log("Registro insertado - Número: " + (index + 1));
      });
    });
  });
});
