//
//Precondicion requiere de la  libreria  para la lectura del EXCEL
// la cual se  instala  con: npm install xlsx --save-dev
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Charge_Randon_Array", () => {
  it("Autocarga_Con_array", { timeout: 1000 }, function () {
    cy.wait(5000);
    cy.visit("https://demoqa.com/text-box");
    cy.wait(1000);
    let numero_pruebas = 5;
    for (let num = 1; num <= numero_pruebas; num++) {
      let estado_Arr = ["1:1", "3:13", "5:32"];
      let Randon_estado =
        estado_Arr[Math.floor(Math.random() * estado_Arr.lenght)];
      let cantidad = Math.floor(Math.random() * 98000);
      let cantidad2 = Math.floor(Math.random() * 78958);

      cy.visit("https://demoqa.com/text-box");
      cy.wait(1000);
      cy.get("#userName")
        .should("be.visible")
        .type("name" + cantidad + cantidad2);
      cy.get("#userEmail")
        .should("be.visible")
        .type("email" + cantidad + "@gmail.com");
      cy.wait(1000);
      cy.get("#currentAddress").type(
        "Madrid con Trinidad" + cantidad + "Las Mercedes"
      );
      cy.wait(1000);
      cy.get("#permanentAddress").type(
        "Calle Nueva York" + cantidad + "Las Mercedes"
      );
    }
  });
});
// });
//});
