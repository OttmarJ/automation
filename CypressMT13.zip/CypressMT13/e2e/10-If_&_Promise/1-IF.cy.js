/*
Testcase/Escenario
valida que el envio sea gratis 
*/
//Recurso:
//PRECONDICIONES

require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("Valida  el  precio a travez del texto ", function () {
  cy.visit("https://www.mercadolibre.com.ve/");
  cy.get(".nav-menu-categories-link").click();
  cy.get(
    ":nth-child(1) > .categories__list > :nth-child(1) > .categories__subtitle > .categories__subtitle-title"
  ).click();
  //Acepta el/los cookies
  cy.get('[data-testid="action:understood-button"]').click();
  cy.wait(2000);
  //determina  texto del precio  atravez de un  objeto tomado
  //de la pagina

  cy.get(
    ".ui-search-result__content-wrapper .ui-search-result__content-columns .ui-search-result__content-column--left .ui-search-item__group--price .ui-search-item__group__element .ui-search-price .ui-search-price__second-line .andes-money-amount .andes-money-amount__currency-symbol"
  ).then(($precio) => {
    cy.log($precio.text());
    $precio = $precio.slice(1.3);
    if ($precio > 30) {
      cy.log("compra de alto valor");
    } else {
      cy.log("compralo");
    }
  });
});
