/*
//PRECONDICION

requiere de la instalacion de npm install cypress-iframe
Importar antes del  describe import 'cypress-iframe'
 ejemplo  de Tutorialspoint Test
 
*/
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

import "cypress-iframe";

it("Iframe_Cypress_Bug", function () {
  // launch URL
  cy.visit("https://demoqa.com/frames");
  // frame loading
  cy.get(
    ".container > .row > .col-12 > #framesWrapper > div:nth-child(1)"
  ).click();
  cy.get("#framesWrapper > :nth-child(1)");
  cy.get("#frame1");
});
