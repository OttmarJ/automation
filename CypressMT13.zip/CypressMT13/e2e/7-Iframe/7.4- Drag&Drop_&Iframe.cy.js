//const { contains } = require("cypress/types/jquery");

//PRECONDICIONES
require("@4tw/cypress-drag-drop");

/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
describe(`new tab`, function () {
  it("one page_new tab", function () {
    cy.visit("https://jqueryui.com/draggable/");
    // cy.get("#column-a").drag("#column-b", { force: true });
    cy.get(".demo-frame");
    cy.contains("Drag me around").debug().click({ force: true });
  });
});
