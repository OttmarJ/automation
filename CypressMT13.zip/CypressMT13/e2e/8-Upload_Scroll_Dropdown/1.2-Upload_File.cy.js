import "cypress-file-upload";
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Upload_File", () => {
  beforeEach(function () {
    cy.visit("https://demoqa.com/automation-practice-form");
    cy.fixture("sld3").then((sld3) => {
      this.sld3 = sld3;
      cy.wait(1000);
    });
  });

  ////////////////////////////////////////////////////////////////////////////////

  it("Upload_File", { timeout: 1000 }, function () {
    /////////////// LLENAR EL FORMULARIO
    cy.wait(3000);
    cy.get("#firstName").type(this.sld3.firstname);
    cy.get("#lastName").type(this.sld3.lastname);
    cy.get("#userEmail").type(this.sld3.email);
    cy.get("#genterWrapper > .col-md-9 > :nth-child(2)").click();
    cy.get("#userNumber").type(this.sld3.tel);
    ///////Seleccion de Fechas
    cy.get("#dateOfBirthInput").click();
    cy.get(".react-datepicker__day--022").click();
    //////Fin  seleccion de fechas

    cy.get(".subjects-auto-complete__value-container").type(this.sld3.sub);

    cy.get("#hobbiesWrapper > .col-md-9 > :nth-child(1)").click();
    cy.get("#currentAddress").type(this.sld3.ca);

    /////////SUBIR EL ARCHIVO /////
    const ruta = "img1.png";

    cy.get("#uploadPicture").attachFile(ruta);
  });
});

//<input id="uploadPicture" type="file" lang="en" class="form-control-file"></input>
