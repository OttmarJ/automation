/*
Escenario: Desarrollar un arreglo 
que permita el logueo en facebook
*/

describe("BeforeEach_Hook_Scenarios", () => {
  const loginDataArray = [
    { email: "correo1@example.com", password: "contraseña1" },
    { email: "correo2@example.com", password: "contraseña2" },
    // Agrega más datos de inicio de sesión si es necesario
  ];

  beforeEach(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://www.facebook.com/login/?next=...");
    cy.wait(5000);
  });

  it("Array_Facebook", function () {
    loginDataArray.forEach((loginData, index) => {
      cy.get('[data-testid="royal_email"]').clear().type(loginData.email);
      cy.get('[data-testid="royal_pass"]').clear().type(loginData.password);
      cy.wait(2000); // Puedes ajustar el tiempo de espera según sea necesario
      cy.get('[data-testid="royal_login_button"]').click(); // Presionar el botón de inicio de sesión

      // Agregar aserciones o acciones adicionales después del inicio de sesión si es necesario
      // Por ejemplo, verificar si el inicio de sesión fue exitoso
    });
  });
});
