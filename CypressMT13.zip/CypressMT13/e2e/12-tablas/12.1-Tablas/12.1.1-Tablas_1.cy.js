/*
Escenario
.
 */

//PRECONDICIONES
import "@cypress/xpath";
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("Tablas con ciclo FOR", function () {
  cy.visit("https://demoqa.com/webtables");

  cy.get(".ReactTable").then((rows) => {
    const rowCount = rows.length;
    // Muestra el conteo de elementos en un cy.log
    cy.log("Cantidad de filas en la tabla: " + rowCount);
  });
});
