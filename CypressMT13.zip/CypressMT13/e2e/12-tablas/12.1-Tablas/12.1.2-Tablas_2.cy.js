/*
Escenario
.
 */

//PRECONDICIONES
import "@cypress/xpath";
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("Tablas con ciclo FOR", function () {
  cy.visit("https://demoqa.com/webtables");

  cy.get(".rt-tbody > :nth-child(1) > .rt-tr > :nth-child(1)").then(
    (elements1) => {
      cy.get(":nth-child(2) > .rt-tr > :nth-child(1)").then((elements2) => {
        cy.get(":nth-child(3) > .rt-tr > :nth-child(1)").then((elements3) => {
          const commonElements = [];
          const uncommonElements = [];

          elements1.each((index, element1) => {
            const text1 = Cypress.$(element1).text();
            const isCommon = elements2.toArray().some((element2) => {
              const text2 = Cypress.$(element2).text();
              return (
                text1 === text2 &&
                elements3.toArray().some((element3) => {
                  const text3 = Cypress.$(element3).text();
                  return text1 === text3;
                })
              );
            });

            if (isCommon) {
              commonElements.push(text1);
            } else {
              uncommonElements.push(text1);
            }
          });

          // Muestra los elementos comunes en un cy.log
          cy.log("Elementos comunes: " + commonElements.length);
          cy.log(commonElements);

          // Muestra los elementos no comunes en un cy.log
          cy.log("Elementos no comunes: " + uncommonElements.length);
          cy.log(uncommonElements);
        });
      });
    }
  );
});
