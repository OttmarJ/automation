/*
 */
describe("Contar arrobas en una tabla de correos electrónicos", () => {
  it("Cuenta la cantidad de arrobas en la tabla y selecciona un elemento al azar", () => {
    cy.visit("https://the-internet.herokuapp.com/tables#delete");

    // Contar las arrobas
    cy.get("#content")
      .invoke("text")
      .then((text) => {
        const count = (text.match(/@/g) || []).length;
        cy.log(`El elemento #content tiene ${count} arroba(s)`);

        // Seleccionar un elemento al azar
        cy.get("table tr").then((rows) => {
          const randomIndex = Cypress._.random(1, rows.length - 1);
          cy.log(
            `Elemento seleccionado al azar: ${rows[randomIndex].innerText}`
          );
        });
      });
  });
});
