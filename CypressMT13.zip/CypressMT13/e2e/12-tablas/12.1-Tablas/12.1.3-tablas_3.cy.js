/*
 */

describe("Contar arrobas en una tabla de correos electrónicos", () => {
  it("Cuenta la cantidad de arrobas en la tabla", () => {
    cy.visit("https://the-internet.herokuapp.com/tables#delete");

    cy.get("#content")
      .invoke("text")
      .then((text) => {
        const count = (text.match(/@/g) || []).length;
        cy.log(`El elemento #content tiene ${count} arroba(s)`);
      });
  });
});
