/*
Escenario: Desarrollar una matriz
que permita el logueo en facebook
*/

describe("BeforeEach_Hook_Scenarios", () => {
  const loginDataMatrix = [
    ["correo1@example.com", "contraseña1"],
    ["correo2@example.com", "contraseña2"],
    ["correo3@example.com", "contraseña3"],
    ["correo4@example.com", "contraseña4"],
    // Agrega más datos de inicio de sesión si es necesario
    // Cada fila de la matriz contiene un correo y una contraseña
  ];

  beforeEach(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://www.facebook.com/login/?next=...");
    cy.wait(5000);
  });

  it("Matrix_Facebook", function () {
    loginDataMatrix.forEach((loginData, index) => {
      const [email, password] = loginData; // Desestructura la fila en correo y contraseña
      cy.get('[data-testid="royal_email"]').clear().type(email);
      cy.get('[data-testid="royal_pass"]').clear().type(password);
      cy.wait(2000); // Puedes ajustar el tiempo de espera según sea necesario
      cy.get('[data-testid="royal_login_button"]').click(); // Presionar el botón de inicio de sesión

      // Agregar aserciones o acciones adicionales después del inicio de sesión si es necesario
      // Por ejemplo, verificar si el inicio de sesión fue exitoso
    });
  });
});
