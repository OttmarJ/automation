//PRECONDICIONES
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
describe(` Page_New_Tab`, function () {
  it("one page_new tab", function () {
    cy.wait(3000);
    cy.visit("https://www.mercantilbanco.com/mercprod/index.html");

    ///////////////////////////////////
    cy.get(".close > .fa").click();
    cy.wait(3000);
    cy.window().then((win) => {
      cy.stub(win, "open", (url) => {
        win.location.href =
          "https://www30.mercantilbanco.com/olb/InitMerc?from=index";
      }).as("popup");
    });
    cy.wait(3000);
    cy.get(".chiclet_grande").click();
    cy.get("@popup").should("be.called");
  });
});
