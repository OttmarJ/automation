/*
Escenario
.
 */

//PRECONDICIONES
import "@cypress/xpath";
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("Invoke_&_Show", function () {
  cy.visit("https://www.seleniumeasy.com/");
  cy.wait(2000);
  cy.get(".logo > img").invoke("attr", "src").should("include", "logo.png");
});
//});
//img[@title="Selenium Easy"]
