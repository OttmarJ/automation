/*
Escenario
.
 */

//PRECONDICIONES
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
it("Invoke_&_Show", function () {
  cy.visit("https://the-internet.herokuapp.com/inputs");
  cy.wait(7000);
  cy.get("p").invoke("hide");
  cy.get("p").invoke("show", "4s");
  cy.get("h3").invoke("hide");
  cy.wait(1000);
  cy.get("p").invoke("show", "4s");
  cy.get("h3").invoke("show", "3s");
});
//});
