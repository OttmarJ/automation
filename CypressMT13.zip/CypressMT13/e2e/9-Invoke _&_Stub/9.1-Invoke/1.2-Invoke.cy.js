/*
Escenario
.
 */

//PRECONDICIONES
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
it("Alias", function () {
  cy.visit("https://demoqa.com/automation-practice-form");
  cy.get("#firstName").invoke("text").as("nom");
  cy.wait(1500);
  cy.get("@nom").then(() => {
    cy.wait(1500);
    cy.get("#lastName").as("apell").type("prueba1");
  });
});
