/*
Escenario
.
 */

//PRECONDICIONES
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
it("Alias", function () {
  cy.visit("https://the-internet.herokuapp.com/inputs");
  cy.get("h3").invoke("text").as("info");
  cy.get("@info").should("contain", "Inputs");
  cy.get("p")
    .should("contain", "Number")
    .then(() => {
      cy.get("input").type("12345");
    });
});
