/*
Escenario
Recurso disponible en
 https://testersdock.com/cypress-new-window/#:~:text=Since%20cypress%20doesn't%20allow,opened%20in%20the%20current%20tab.
 */

//PRECONDICIONES
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
describe(` RemoveAttr`, function () {
  it("invoke", function () {
    cy.visit("https://the-internet.herokuapp.com/windows");

    cy.wait(2000);
    cy.get(".example > a").invoke("removeAttr", "target").click();
    cy.url().should("include", "/windows/new");
    cy.get("h3").should("have.text", "New Window");
  });
});
