//PRECONDICIONES
require("@4tw/cypress-drag-drop");

/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
//****/
describe(`RangeSlide_Click`, function () {
  it("Rangeslide", function () {
    cy.visit("https://www.w3schools.com/howto/howto_js_rangeslider.asp");

    cy.wait(6000);
    cy.get("#slidecontainer > :nth-child(2)").invoke("attr", "value", "0");
  });
});
