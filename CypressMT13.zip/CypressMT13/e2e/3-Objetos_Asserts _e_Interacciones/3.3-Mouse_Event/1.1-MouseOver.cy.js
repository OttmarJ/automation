//const { contains } = require("cypress/types/jquery");

//PRECONDICIONES
require("@cypress/xpath");
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
describe(`eventos del Mouse`, function () {
  it("one pa", function () {
    cy.visit("https://www.w3schools.com/howto/howto_js_dropdown.asp");
    cy.get('.w3-bar > [href="/php/default.asp"]').trigger("mouseover").click();
  });
});
