//PRECONDICIONES
require("@4tw/cypress-drag-drop");

/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
describe(`Simple_Drag&Drop`, function () {
  it("Simple_Drag&Drop", function () {
    cy.visit("https://the-internet.herokuapp.com/drag_and_drop");
    cy.get("#column-a").drag("#column-b", { force: true });
  });
});
