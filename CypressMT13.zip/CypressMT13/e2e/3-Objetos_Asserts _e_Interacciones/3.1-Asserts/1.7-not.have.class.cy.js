/*
Testcase/Escenario
valida que el envio sea gratis 
*/
//Recurso:
//PRECONDICIONES

require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("not.have.class ", function () {
  cy.visit("https://demoqa.com/text-box");
  cy.get("#userName")
    .should("be.visible")
    .should("not.have.class", "mr-sm-22")
    .then(() => {
      cy.get("#userName").type("prueba");
    });
});
