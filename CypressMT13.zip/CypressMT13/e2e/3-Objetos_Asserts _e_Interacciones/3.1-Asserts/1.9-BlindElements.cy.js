/*
RETO
Desarrollar un bot capaz de detectar mediante 
el objeto mediante texto los elementos 
All Courses , Video Tutorial  y Resources
Ademas de  acceder  al practice site  del 
elemento 1
*/
//
require("@cypress/xpath");
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
describe(`blind elements`, function () {
  it("one page_new tab", function () {
    cy.visit("https://www.way2automation.com/");

    cy.contains("Resources").trigger("mouseover", { force: true });
  });
});
