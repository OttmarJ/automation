/*
Testcase/Escenario
valida las longitudes de la cadena 
*/
//Recurso:https://medium.com/@anshita.bhasin/how-to-get-element-text-in-cypress-71c68814d20
//PRECONDICIONES

require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("Lenght_Css ", function () {
  cy.visit("http://the-internet.herokuapp.com/tables");
  // cy.get('#table1 > thead > tr > :nth-child(1) > span')
  cy.get("#table1 > thead > tr > ").should("have.length", 6);
  cy.get("#table1 > tbody > :nth-child(1) > :nth-child(1)").should(
    "have.length",
    1
  );
});
