/*
Descripcion

*/

//PRECONDICIONES

/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
//test
it("Interacciones", function () {
  cy.visit("https://demoqa.com/browser-windows");
  cy.get("#messageWindowButton").click({ force: true });

  cy.title(
    "Knowledge increases by sharing but not by saving. Please share this website with your friends and in your organization.Knowledge increases by sharing but not by saving. Please share this website with your friends and in your organization. "
  );
});
