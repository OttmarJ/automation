/*
Descripcion/Test/Case
*/

//PRECONDICION
//requiere de la instalacion del plugin tab npm install -D cypress-plugin-tab
//npm install -D cypress-plugin-tab
//At the top of cypress/support/index.js:
//require('cypress-plugin-tab')
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("have&value", () => {
  it("have&value", function () {
    cy.visit("https://demoqa.com/automation-practice-form");
    cy.get("#firstName").should("have.text", "");
    cy.wait(1500);
    cy.get("#lastName").should("contain.text", "");
    /////////
    cy.wait(1500);
    cy.get("#firstName").type("prueba").should("contain.value", "prueba");
    cy.wait(1500);
    cy.get("#lastName").type("prueba").should("contain.value", "prueba");
    ///////
  });
});
