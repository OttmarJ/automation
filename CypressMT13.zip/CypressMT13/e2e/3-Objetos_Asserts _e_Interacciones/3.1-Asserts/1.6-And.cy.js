/*
Testcase/Escenario
valida que el envio sea gratis empleado and 
*/
//Recurso:
//PRECONDICIONES

require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("HaveClass ", function () {
  cy.visit("https://demoqa.com/text-box");
  cy.get("#userName")
    .should("be.visible")
    .and("have.class", "mr-sm-2")
    .then(() => {
      cy.get("#userName").type("prueba");
    });
});
