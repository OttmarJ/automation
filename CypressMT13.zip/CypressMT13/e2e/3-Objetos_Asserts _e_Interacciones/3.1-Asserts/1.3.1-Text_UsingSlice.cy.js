/*
Testcase/Escenario
valida que el envio sea gratis 
*/
//Recurso:https://medium.com/@anshita.bhasin/how-to-get-element-text-in-cypress-71c68814d20
//PRECONDICIONES

require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
//TEST
it("Valida  el  precio a travez del texto ", function () {
  cy.visit("https://www.mercadolibre.com.ve/");
  cy.get(".nav-menu-categories-link").click();
  cy.get(
    ":nth-child(1) > .categories__list > :nth-child(1) > .categories__subtitle > .categories__subtitle-title"
  ).click();
  //Acepta el/los cookies
  cy.get('[data-testid="action:understood-button"]').click();
  cy.wait(2000);
  //determina  texto del precio usando un selector de  la pagina
  // pero simplificado  con inteligencia artificial

  cy.get(
    ".ui-search-price__second-line > .andes-money-amount > .andes-money-amount__currency-symbol"
  ).then(($precio) => {
    cy.log($precio.text());
    $precio = $precio.slice(4.9);
  });
});
