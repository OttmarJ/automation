/*
Descripcion

*/

//PRECONDICIONES

require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Introduccion  a los Assert_ ", () => {
  beforeEach(function () {
    cy.visit("https://www.google.com/");
  });
  //});

  it("  title Assert", function () {
    cy.title().should("eq", "Google");
    cy.wait(1500);
    cy.get(".FPdoLc > center > .gNO89b").should("be.visible");
    cy.wait(1500);
    cy.get(".gLFyf").type("Cypress.io {enter}");
  });

  it("Assert Contains", function () {
    cy.wait(1500);
    cy.contains("Google");
    cy.get(".FPdoLc > center > .gNO89b").should("be.visible");
    cy.wait(1500);
    cy.get(".gLFyf").type("Udemy {enter}");
  });
});
