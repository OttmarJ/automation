/*
Descripcion

*/

//PRECONDICIONES
require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
//Test
describe("Introduccion  a los Assert_ ", () => {
  beforeEach(function () {
    cy.visit("https://www.coursera.com/");
  });
  //});

  it("be visible", function () {
    cy.wait(1500);
    cy.get(".rc-CourseraLogo").should("be.visible");
  });

  it("Exist", function () {
    cy.get(".css-bikj3b").should("exist");
  });
  it("not.have.value", function () {
    cy.get(".react-autosuggest__input").type("Pedro Perez");
    //  .should("have.text", "Pedro Perez");
    cy.wait(1500);
    cy.get(".react-autosuggest__input").should("not.have.value", "Jane");
  });
  it("have.value", function () {
    cy.get(".react-autosuggest__input").type("Jane");
    cy.wait(1500);
    cy.get(".react-autosuggest__input").should("have.value", "Jane");
  });

  it.only("and", function () {
    cy.get(".react-autosuggest__input").type("Jane");
    cy.wait(1500);
    cy.get(".react-autosuggest__input")
      .should("have.value", "Jane")
      .should("not.have.value", "Pedro");
  });
});
