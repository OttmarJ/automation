/*
Descripcion
valida que el envio sea gratis empleando then
*/
//Recurso:https://medium.com/@anshita.bhasin/how-to-get-element-text-in-cypress-71c68814d20
//PRECONDICIONES
////////
require("@cypress/xpath");
//<reference types="cypress" />;

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
//Test
it("Valida  el  text", function () {
  cy.visit("https://www.mercadolibre.com.ve/");
  cy.get(".nav-menu-categories-link").click();
  cy.get(
    ":nth-child(1) > .categories__list > :nth-child(1) > .categories__subtitle > .categories__subtitle-title"
  ).click();
  //Acepta el/los cookies
  cy.get('[data-testid="action:understood-button"]').click();
  cy.wait(2000);
  //determina si el envio es gratis

  cy.get(
    ":nth-child(1) > .ui-search-result__wrapper > .andes-card > .ui-search-result__content-wrapper > .ui-search-result__content-columns > .ui-search-result__content-column--left > .ui-search-item__group--shipping > .ui-search-item__group__element > .ui-search-item__shipping"
  ).then(($gratis) => {
    let gratis = $gratis.text();
    cy.log("el envio es gratis");
  });
});
