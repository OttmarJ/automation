/*
Testcase/Escenario
valida que el envio sea gratis 
*/
//Recurso:
//PRECONDICIONES

require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("HaveClass ", function () {
  cy.visit("https://demoqa.com/text-box");
  cy.wait(5000);
  cy.get("#userName")
    .should("be.visible")
    .should("have.class", "mr-sm-2")
    .then(() => {
      cy.get("#userName").type("prueba");
    });
});
