/*
Testcase/Escenario
valida el contro del tiempo a travez de  una variable de tiempo
*/
//Recurso:
//PRECONDICIONES

require("@cypress/xpath");
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("Lenght_Css ", function () {
  cy.visit("http://the-internet.herokuapp.com/tables");
  let tiempo = 4000;

  cy.get("#table1 > thead > tr > ").should("have.length", 6);
  cy.wait(tiempo);
  cy.get("#table1 > tbody > :nth-child(1) > :nth-child(1)").should(
    "have.length",
    1
  );
});
