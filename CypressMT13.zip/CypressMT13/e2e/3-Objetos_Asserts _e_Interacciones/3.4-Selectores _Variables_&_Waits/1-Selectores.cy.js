/*
Testcase/Escenario



//PRECONDICIONES


 
*/
require("@cypress/xpath");
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Selectores", () => {
  beforeEach(function () {
    cy.visit("https://demoqa.com/");
  });

  ////////////////////////////////////////////////////////////////////////////////

  it("ID", { timeout: 1000 }, function () {
    /////////////// Todos los selectores
    cy.get(":nth-child(3) > :nth-child(1) > .avatar").click();
    cy.get(":nth-child(2) > .group-header > .header-wrapper").click();
    cy.get(
      ":nth-child(2) > .element-list > .menu-list > #item-0 > .text"
    ).click();
    ////cy, get("#user").type("Jose");
  });

  it("Atributos", { timeout: 1000 }, function () {
    cy.get(":nth-child(3) > :nth-child(1) > .avatar").click();
    cy.get(":nth-child(2) > .group-header > .header-wrapper").click();
    cy.get(
      ":nth-child(2) > .element-list > .menu-list > #item-0 > .text"
    ).click();
    cy.wait(3000);
    cy.get('input[placeholder*="First Name"]').type("Pedro");
    //////////////////
    /*
//FIN DEL TEST//
*/
  });

  it("Xpath", function () {
    cy.get(":nth-child(3) > :nth-child(1) > .avatar").click();
    cy.get(":nth-child(2) > .group-header > .header-wrapper").click();
    cy.get(
      ":nth-child(2) > .element-list > .menu-list > #item-0 > .text"
    ).click();
    cy.xpath("//*[@id='firstName']").type("Pedro");
  });

  it("Contains", function () {
    cy.get(":nth-child(3) > :nth-child(1) > .avatar").click();
    cy.get(":nth-child(2) > .group-header > .header-wrapper").click();
    cy.get(
      ":nth-child(2) > .element-list > .menu-list > #item-0 > .text"
    ).click();
    cy.contains("Female").click();
    //FIN DEL TEST//
  });
  it("CopySelector", function () {
    //FIN DEL TEST//
    cy.get(":nth-child(3) > :nth-child(1) > .avatar").click();
    cy.get(":nth-child(2) > .group-header > .header-wrapper").click();
    cy.get(
      ":nth-child(2) > .element-list > .menu-list > #item-0 > .text"
    ).click();
    cy.get(
      "#genterWrapper > div.col-md-9.col-sm-12 > div:nth-child(2) > label"
    ).click();
  });
  it("Xpath Text", function () {
    //FIN DEL TEST//
    cy.get(":nth-child(3) > :nth-child(1) > .avatar").click();
    cy.get(":nth-child(2) > .group-header > .header-wrapper").click();
    cy.xpath("//span[text()= 'Practice Form']").click();
    cy.get("#firstName").type("hola");
  });
});
