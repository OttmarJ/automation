/*
Testcase/Escenario



//PRECONDICIONES

 
 
*/
require("@cypress/xpath");
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Waits", () => {
  beforeEach(function () {
    cy.visit("https://demoqa.com/select-menu");
  });

  ////////////////////////////////////////////////////////////////////////////////

  it("Select Value_ click", { timeout: 1000 }, function () {
    /////////////// Todos los selectores
    cy.get(
      "#withOptGroup > .css-yk16xz-control > .css-1wy0on6 > .css-tlfecz-indicatorContainer"
    ).click();
    cy.wait(1500);

    cy.get("#react-select-2-option-0-0").click();
  });

  it("Select_Value", { timeout: 1000 }, function () {
    /////////////// Todos los selectores
    cy.get(
      "#withOptGroup > .css-yk16xz-control > .css-1wy0on6 > .css-tlfecz-indicatorContainer"
    ).click();
    cy.wait(1500);

    cy.contains("Group 1, option 1")

      .debug()
      .click({ force: true });
  });
});
