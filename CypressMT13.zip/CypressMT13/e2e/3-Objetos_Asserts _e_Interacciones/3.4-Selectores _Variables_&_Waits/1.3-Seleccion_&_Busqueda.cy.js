/*
Testcase/Escenario/Descripcion
Desarrollar  un teste el cual permita la seleccion y busqueda 
mediante el uso del force click

//PRECONDICIONES

*/
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

//Test
describe("Seleccion_&_Busqueda", () => {
  beforeEach(function () {
    cy.visit("https://demoqa.com/");
  });

  ////////////////////////////////////////////////////////////////////////////////

  it("force_clic", { timeout: 1000 }, function () {
    ///////////////
    cy.get(".category-cards > :nth-child(5) > :nth-child(1)").click();
    cy.wait(1500);
    cy.get(":nth-child(1) > .group-header > .header-wrapper").click();
    cy.wait(1500);
    cy.get(":nth-child(1) > .element-list > .menu-list > #item-3").click();
    cy.get("#addNewRecordButton").click();
    cy.get("#firstName").type("JUan");
    cy.get("#lastName").type("Peres");
    cy.get("#userEmail").type("JP@gmail.com");
    cy.get("#age").type("35");
    cy.get("#salary").type("500");
    cy.get("#department").type("QA");
    cy.get("#submit").click();
    /////////
    cy.get("#searchBox").type("QA");
    cy.get("#searchBox").clear;
  });
});
