/*
Testcase/Escenario/Descripcion



//PRECONDICIONES


 
 
*/
require("@cypress/xpath");
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("ComboBox_Select", () => {
  beforeEach(function () {
    cy.visit("https://computer-database.gatling.io/computers");
  });

  ////////////////////////////////////////////////////////////////////////////////

  it("ComboBox", { timeout: 1000 }, function () {
    /////////////// Todos los selectores
    cy.get("#searchbox").type("ACE");
    cy.get("#searchsubmit").click();
    cy.get("tbody > :nth-child(1) > :nth-child(1) > a").click();
    cy.get("#introduced").type("2023/02/20");
    cy.get("#discontinued").type("2024/02/20");
    cy.get("#company")
      .should("be.visible")
      .select("Nokia")
      .should("have.value", "16")
      .wait(1500);
    cy.get(".primary").click();
  });
});
