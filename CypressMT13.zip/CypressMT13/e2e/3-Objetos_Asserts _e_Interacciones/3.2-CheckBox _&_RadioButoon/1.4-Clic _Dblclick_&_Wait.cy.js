/*
Testcase/Escenario/Descripcion
Desarrollar un test  case , que se enganche de manera simple con  BEFORE EACH 
el cual permita  la ejecucion de  clics  y clicks dobles y 
esperas en una interfaz 
*/

//PRECONDICIONES

/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Click_DblClick_&_Wait", () => {
  beforeEach(function () {
    cy.visit("https://demoqa.com/");
  });

  ////////////////////////////////////////////////////////////////////////////////

  it("force_clic", { timeout: 1000 }, function () {
    ///////////////
    cy.get(":nth-child(5) > :nth-child(1) > .card-body").click({ force: true });
    cy.wait(2000);
    cy.go(-1);
  });

  it("Clic", { timeout: 1000 }, function () {
    //////////////////
    cy.get(":nth-child(5) > :nth-child(1) > .card-body").click();
    cy.wait(2000);
    cy.get(":nth-child(1) > .group-header > .header-wrapper").click();
    cy.wait(2000);

    cy.get(":nth-child(1) > .element-list > .menu-list > #item-1").click();
    cy.wait(2000);
    cy.get(".rct-checkbox").click();
    /*
//FIN DEL TEST//
*/
  });

  it("dblclic", function () {
    cy.get(":nth-child(5) > :nth-child(1) > .card-up").click();
    cy.get(":nth-child(1) > .group-header > .header-wrapper").click();
    cy.wait(2000);
    cy.get(":nth-child(1) > .element-list > .menu-list > #item-4").click();
    cy.wait(2000);

    // cy.get(":nth-child(1) > .element-list > .menu-list > #item-4");
    cy.get("#doubleClickBtn").dblclick();
    //FIN DEL TEST//
  });
  it("rightclic", function () {
    cy.get(":nth-child(5) > :nth-child(1) > .card-up").click();
    cy.get(":nth-child(1) > .group-header > .header-wrapper").click();
    cy.wait(2000);
    cy.get(":nth-child(1) > .element-list > .menu-list > #item-4").click();
    cy.wait(2000);

    // cy.get(":nth-child(1) > .element-list > .menu-list > #item-4");
    cy.get("#rightClickBtn").rightclick();
    //FIN DEL TEST//
  });
  it.only("clic por coordenadas", function () {
    cy.get(":nth-child(5) > :nth-child(1) > .card-up").click();
    cy.get(":nth-child(1) > .group-header > .header-wrapper").click();
    cy.wait(2000);
    cy.get(":nth-child(1) > .element-list > .menu-list > #item-4").click();
    cy.wait(2000);

    cy.get("#rightClickBtn").rightclick(15, 40, { force: true });
    //FIN DEL TEST//
  });
});
