/*
Testcase/Escenario/Descripcion

desarrollar un test que permita la conexion  a una pagina determinada 
inserte un valor y haga clic  en el

//PRECONDICIONES


 
  
*/
require("@cypress/xpath");
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("", () => {
  beforeEach(function () {
    cy.visit("https://www.google.com/");
  });

  ////////////////////////////////////////////////////////////////////////////////

  it("Select Value_ click", { timeout: 1000 }, function () {
    /////////////// Todos los selectores
    cy.wait(1500);
    cy.get(".gLFyf").focus().click().type("ferrari");
    cy.wait(1500);
    cy.get("#gb").click();
    cy.wait(1500);
    // cy.get(".gLFyf").trigger("keydown", { keyCode: 27, which: 27 });
    cy.get(".FPdoLc > center > .gNO89b").click();
  });
});
