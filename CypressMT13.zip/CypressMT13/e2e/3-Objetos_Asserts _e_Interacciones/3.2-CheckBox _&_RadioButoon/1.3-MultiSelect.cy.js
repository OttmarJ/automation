/*
Testcase/Escenario/Descripcion



//PRECONDICIONES


 
 
*/
require("@cypress/xpath");
/// <reference types="cypress" />
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("", () => {
  beforeEach(function () {
    cy.visit(
      "https://www.cssscript.com/demo/dual-list-box-javascript-multi-js/"
    );
  });

  ////////////////////////////////////////////////////////////////////////////////

  it("Multiselect", function () {
    cy.get('[data-value="Banana"]')
      .click()
      .then(() => {
        cy.get('[data-value="Cherry"]')
          .click()
          .then(() => {
            cy.get('[data-value="Coconut"]').click();
            cy.log("se movieron todos los elementos");
          });
      });
  });
});
