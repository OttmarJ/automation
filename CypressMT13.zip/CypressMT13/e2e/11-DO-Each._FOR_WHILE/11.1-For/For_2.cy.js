describe("Bucles for  y Each", () => {
  it("For dos", () => {
    for (let i = 1; i < 1000; i = i + 2) cy.log("prueba");
  });
});
