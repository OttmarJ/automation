//describe("Bucles for  y Each", () => {
it("For", () => {
  cy.visit("https://www.mercadolibre.com.ve/");
  cy.get(".nav-menu-categories-link").click();
  cy.get(
    ":nth-child(1) > .categories__list > :nth-child(1) > .categories__subtitle > .categories__subtitle-title"
  ).click();
  //Acepta el/los cookies
  cy.get('[data-testid="action:understood-button"]').click();
  cy.wait(2000);

  let contador = 0;
  cy.get(".andes-card .ui-search-result-image__element")

    .then(($elements) => {
      const totalElementos = Math.min($elements.length, 4); // Limita el bucle a un máximo de 4 elementos
      for (let i = 0; i < totalElementos; i++) {
        const $el = $elements.eq(i);
        contador++;
      }
    })
    .then(() => {
      cy.log(`Se hicieron clic en ${contador} elementos de la página.`);
    });
});
//});
