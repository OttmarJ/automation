describe("Bucles for  y Each", () => {
  it("For tres", () => {
    for (let i = 1; i < 10; i++) {
      let t = 5;
      cy.log(t + " x " + i + "=" + t * 1);
    }
  });
});
