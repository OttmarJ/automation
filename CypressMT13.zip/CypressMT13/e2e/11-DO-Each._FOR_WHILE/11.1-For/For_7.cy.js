//describe("Bucles for  y Each", () => {
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("For", () => {
  cy.visit("https://demoqa.com/buttons");
  let contador = 0;
  cy.contains("Click Me")
    .then(($element) => {
      for (let i = 0; i < 40; i++) {
        cy.wrap($element).click();
        contador++;
        cy.wait(250); // Espera de medio segundo (500 milisegundos)
      }
    })
    .then(() => {
      cy.log(`Se realizaron ${contador} clics.`);
    });
});
