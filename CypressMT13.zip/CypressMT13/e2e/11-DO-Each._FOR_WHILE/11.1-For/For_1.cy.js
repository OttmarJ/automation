describe("Bucles for  y Each", () => {
  it("For uno", () => {
    for (let i = 1; i < 1000; i++) cy.log("prueba");
  });
});
