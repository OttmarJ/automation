//describe("Bucles for  y Each", () => {
it("For", () => {
  cy.visit("https://www.mercadolibre.com.ve/");
  cy.get(".nav-menu-categories-link").click();
  cy.get(
    ":nth-child(1) > .categories__list > :nth-child(1) > .categories__subtitle > .categories__subtitle-title"
  ).click();
  //Acepta el/los cookies
  cy.get('[data-testid="action:understood-button"]').click();
  cy.wait(2000);

  let contador = 0;
  cy.get(".andes-card .ui-search-result-image__element")
    .each(($el, index, $list) => {
      contador++;
    })
    .then(() => {
      cy.log(`Se encontraron ${contador} imágenes en la página.`);
    });
});
