//describe("Bucles for  y Each", () => {
it("For", () => {
  cy.visit("https://www.mercadolibre.com.ve/");
  cy.get(".nav-menu-categories-link").click();
  cy.get(
    ":nth-child(1) > .categories__list > :nth-child(1) > .categories__subtitle > .categories__subtitle-title"
  ).click();
  //Acepta el/los cookies
  cy.get('[data-testid="action:understood-button"]').click();
  cy.wait(2000);
  // Inicia el contador  para cada elemento del indice  que incluye la frase envio gratis
  let contador = 0;
  cy.get(".ui-search-item__shipping")
    .each(($el, index, $list) => {
      const texto = $el.text();
      if (texto.includes("Envío gratis")) {
        contador++;
        if (contador <= 60) {
          // Cambia "5" por el número máximo de clics que desees hacer
          cy.wrap($el).click();
        } else {
          return false; // Detiene el ciclo each después de alcanzar el límite
        }
      }
    })
    .then(() => {
      cy.log(
        `Se hicieron ${contador} clics en elementos que contienen "Envio Gratis"`
      );
    });
});
