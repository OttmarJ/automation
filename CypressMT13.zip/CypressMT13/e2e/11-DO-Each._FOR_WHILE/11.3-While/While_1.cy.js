//describe("Bucles for  y Each", () => {
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("While", () => {
  cy.visit("https://demoqa.com/buttons");
  let contador = 0;
  cy.contains("Click Me")
    .then(($element) => {
      let i = 0;
      do {
        cy.wrap($element).click();
        contador++;
        cy.wait(250); // Espera de medio segundo (250 milisegundos)
        i++;
      } while (i < 40);
    })
    .then(() => {
      cy.log(`Se realizaron ${contador} clics.`);
    });
});
//});
//});
