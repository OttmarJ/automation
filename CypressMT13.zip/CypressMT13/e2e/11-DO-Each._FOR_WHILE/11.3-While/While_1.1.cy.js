/*

*/
//describe("Bucles for  y Each", () => {
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("While", () => {
  cy.visit("https://demoqa.com/buttons");
  let contador = 0;
  cy.contains("Click Me")
    .then(($element) => {
      let i = 0;
      while (i < 100) {
        cy.wrap($element).click();
        contador++;
        cy.wait(500); // Espera de medio segundo (500 milisegundos)
        i++;
      }
    })
    .then(() => {
      cy.log(`Se realizaron ${contador} clics.`);
    });
});
//});
//});
