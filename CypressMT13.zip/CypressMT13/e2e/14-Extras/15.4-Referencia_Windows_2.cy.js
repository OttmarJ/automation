const { should } = require("chai");

describe("Validar Url", () => {
  it("Windows_Chart_set", () => {
    // cy.title().should("eq", "THE NUMBER GUESSING GAME");
    cy.visit(" https://testsheepnz.github.io/index.html#the-number-game");
    cy.document().should("have.property", "charset").and("eq", "UTF-8");
    cy.url().should(
      "include",
      "https://testsheepnz.github.io/index.html#the-number-game"
    );
  });
});
