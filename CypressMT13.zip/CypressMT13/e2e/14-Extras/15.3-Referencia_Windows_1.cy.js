describe("Referencias a Windows", () => {
  it("Windows_Chart_set", () => {
    cy.visit(" https://testsheepnz.github.io/index.html#the-number-game");
    cy.document().should("have.property", "charset").and("eq", "UTF-8");
  });
});
