/*
DESCRIPCION
-- Desarrrollar un gancho que permita  la conexion a una pagina
 web empleando  before y a Aftereach
*/
//
//PRECONDICIONES

//<reference types="cypress" />;
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Expresiones_Regulares", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://demoqa.com/ ");
  });
  it("Regex", function () {
    cy.contains("Elements").click();
  });
  afterEach(function () {
    cy.log("after Each test");
  });
});

////////////////
