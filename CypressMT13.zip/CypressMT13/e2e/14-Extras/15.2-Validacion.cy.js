//<reference types="cypress" />;

/*
 Test para la validacion  del funcionamiento  de lo
 ejercicios

describe("Validacion web", function () {
  Cypress.on("uncaught:exception", (err, runnable) => {
    return false;
  });

  it("mercantilseguros.com", function () {
    cy.visit("https://www.mercantilseguros.com/login.html");
  });

  it("fastinsuranceservices.net", function () {
    cy.visit("https://fastinsuranceservices.net/#/car-coverage");
  });
});

it("demoqa.com/automation-practice-form", function () {
  cy.visit("https://demoqa.com/automation-practice-form");
});

it("demoqa.com/text-box", function () {
  cy.visit("https://demoqa.com/text-box");
});

it("accounts-google", function () {
  cy.visit(
    "https://accounts.google.com/signin/v2/identifier?hl=es&flowName=GlifWebSignIn&flowEntry=ServiceLogin"
  );
});

it("Simple_hook", function () {
  cy.visit("https://fastinsuranceservices.net/#/car-1-year");
});

it("google.com", function () {
  cy.visit("https://www.google.com/?hl=es");
});

it("coursera.com", function () {
  cy.visit("https://www.coursera.com/");
});

it("demoqa.com", function () {
  cy.visit("https://demoqa.com/browser-windows");
});

it("the-internet.herokuapp", function () {
  cy.visit("http://the-internet.herokuapp.com/tables");
});

it("mercadolibre", function () {
  cy.visit("https://www.mercadolibre.com.ve/");
});

it("computer-database.gatling.io", function () {
  cy.visit("https://computer-database.gatling.io/computers");
});

it("way2automation", function () {
  cy.visit("https://www.way2automation.com/");
});

it("www.cssscript.com", function () {
  cy.visit("https://www.cssscript.com/demo/dual-list-box-javascript-multi-js/");
});

it("herokuapp.com/drag_and_drop", function () {
  cy.visit("https://the-internet.herokuapp.com/drag_and_drop");
});

it("www.w3schools.com/howto", function () {
  cy.visit("https://www.w3schools.com/howto/howto_js_dropdown.asp");
});

it("demoqa.com/select-menu", function () {
  cy.visit("https://demoqa.com/select-menu");
});

it("date-picker", function () {
  cy.visit("https://demoqa.com/date-picker");
});

it("facebook", function () {
  cy.visit("https://es-la.facebook.com/");
});

it("https://jqueryui.com", function () {
  cy.visit("https://jqueryui.com/draggable/");
});

it("https://demoqa.com/frames", function () {
  cy.visit("//demoqa.com/frames ");
});

it("demoqa.com/automation-practice-form", function () {
  cy.visit("https://demoqa.com/automation-practice-form");
});

it(" herokuapp.com/inputs", function () {
  cy.visit("https://the-internet.herokuapp.com/inputs");
});

it("seleniumeasy.com", function () {
  cy.visit("https://www.seleniumeasy.com/");
});

it("the-internet.herokuapp.com/javascript_alerts", function () {
  cy.visit("https://the-internet.herokuapp.com/javascript_alerts");
});

it("demoqa.com/buttons", function () {
  cy.visit(" https://demoqa.com/buttons");
});

it("demoqa.com/webtables", function () {
  cy.visit("https://demoqa.com/webtables");
});

it("demoqa.com/webtables", function () {
  cy.visit("https://demoqa.com/webtables");
});

it("tables#delete", function () {
  cy.visit("  https://the-internet.herokuapp.com/tables#delete");
});
*/
